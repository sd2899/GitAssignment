<!DOCTYPE html>
<html>
<body>

<h1>My first PHP page</h1>

<?php
echo "Updated Hello World!";
?> 

</body>
</html>

